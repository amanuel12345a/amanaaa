import json
import os
import sys
import urllib.error
import urllib.request

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from enumerate_devices import enumerate_devices
from monitor_device_availability import has_static_ip, ping_device

CSV_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "network_devices.csv")
TICKET_URL = "http://localhost:8080/tickets"
ISSUE_TYPE = "Device Unavailable"


def create_ticket(device):
    payload = json.dumps({
        "device_name": device["Device Name"],
        "ip_address": device["Device Address"],
        "issue_type": ISSUE_TYPE,
    }).encode()

    req = urllib.request.Request(
        TICKET_URL,
        data=payload,
        headers={"Content-Type": "application/json"},
        method="POST",
    )

    try:
        with urllib.request.urlopen(req, timeout=5) as resp:
            return resp.status, json.loads(resp.read())
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read())
    except urllib.error.URLError as e:
        return None, {"error": str(e.reason)}


def main():
    devices = enumerate_devices(CSV_FILE)

    print("=" * 65)
    print("DEVICE UNAVAILABILITY TICKETING")
    print(f"Issue type: {ISSUE_TYPE}")
    print(f"Ticket service: {TICKET_URL}")
    print("=" * 65)

    created = 0
    failed = 0

    for d in devices:
        address = d["Device Address"]
        if not has_static_ip(address):
            print(f"[SKIP] {d['Device Name']:<8} | {address:<18} | No static IP (not monitored)")
            continue
        if not ping_device(address):
            name = d["Device Name"]
            status, response = create_ticket(d)

            if status == 201:
                ticket = response.get("ticket_id", "?")
                print(f"[OK]  Ticket #{ticket} | {name:<8} | {address:<18} | {response.get('message', '')}")
                created += 1
            else:
                err = response.get("error", "unknown error")
                print(f"[FAIL] {name:<8} | {address:<18} | {err}")
                failed += 1

    print("-" * 65)
    print(f"Total: {created} tickets created, {failed} failed")
    print("=" * 65)


if __name__ == "__main__":
    main()