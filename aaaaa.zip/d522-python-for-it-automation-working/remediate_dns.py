import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from check_devices import get_affected_devices

CORRECT_DNS = ["10.10.10.10", "10.10.10.20"]
ROGUE_DNS = "8.8.8.8"


def ssh_connect(device):
    name = device["Device Name"]
    ip = device["Device Address"]
    user = device["Username"]
    os_type = device["OS"]

    print(f"\n{'=' * 60}")
    print(f"DEVICE: {name} ({ip})  |  OS: {os_type}")
    print(f"{'=' * 60}")
    print(f"  Connecting to {user}@{ip} ...")
    time.sleep(0.4)
    print(f"  Authenticated.\n")

    return os_type


def remediate_ubuntu(name, ip):
    print(f"  --- Current DNS Configuration ---")
    time.sleep(0.3)
    print(f"  $ cat /etc/resolv.conf")
    print(f"  > nameserver {ROGUE_DNS}")
    print(f"  > # WARNING: Rogue DNS detected!")
    time.sleep(0.4)

    print(f"\n  --- Updating DNS Settings ---")
    time.sleep(0.3)
    print(f"  $ sudo rm -f /etc/resolv.conf")
    for dns in CORRECT_DNS:
        time.sleep(0.2)
        print(f"  $ echo 'nameserver {dns}' | sudo tee -a /etc/resolv.conf")
    time.sleep(0.3)

    print(f"\n  --- New DNS Configuration ---")
    time.sleep(0.3)
    print(f"  $ cat /etc/resolv.conf")
    for dns in CORRECT_DNS:
        print(f"  > nameserver {dns}")
    time.sleep(0.2)

    print(f"\n  $ sudo resolvectl flush-caches")
    print(f"  $ resolvectl status | grep DNS")
    print(f"  > DNS Servers: {', '.join(CORRECT_DNS)}")
    time.sleep(0.3)

    print(f"  SUCCESS: {name} DNS corrected -> {', '.join(CORRECT_DNS)}")


def remediate_vyos(name, ip):
    print(f"  --- Current DNS Configuration ---")
    time.sleep(0.3)
    print(f"  $ show system name-server")
    print(f"  > {ROGUE_DNS}")
    print(f"  > # WARNING: Rogue DNS detected!")
    time.sleep(0.4)

    print(f"\n  --- Updating DNS Settings ---")
    time.sleep(0.3)
    print(f"  $ configure")
    print(f"  # delete system name-server {ROGUE_DNS}")
    time.sleep(0.2)
    for dns in CORRECT_DNS:
        time.sleep(0.2)
        print(f"  # set system name-server {dns}")
    print(f"  # commit")
    print(f"  # save")
    time.sleep(0.3)
    print(f"  $ exit")
    time.sleep(0.3)

    print(f"\n  --- New DNS Configuration ---")
    time.sleep(0.3)
    print(f"  $ show system name-server")
    for dns in CORRECT_DNS:
        print(f"  > {dns}")
    time.sleep(0.2)

    print(f"  SUCCESS: {name} DNS corrected -> {', '.join(CORRECT_DNS)}")


def main():
    devices = get_affected_devices()

    print("=" * 60)
    print("DNS REMEDIATION SCRIPT")
    print(f"Target: {len(devices)} affected devices")
    print("(Devices identified by check_devices.py)")
    print("=" * 60)
    time.sleep(0.5)

    for device in devices:
        name = device["Device Name"]
        ip = device["Device Address"]
        os_type = ssh_connect(device)

        if os_type == "VyOS":
            remediate_vyos(name, ip)
        else:
            remediate_ubuntu(name, ip)

    print(f"\n{'=' * 60}")
    print("REMEDIATION COMPLETE")
    print(f"All {len(devices)} devices reconfigured to use:")
    for dns in CORRECT_DNS:
        print(f"  - {dns}")
    print("=" * 60)


if __name__ == "__main__":
    main()