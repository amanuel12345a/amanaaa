import os
import smtplib
import sys
from datetime import datetime
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from check_devices import get_affected_devices

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
ENV_FILE = os.path.join(SCRIPT_DIR, ".env")

EMAIL_SUBJECT = "RESOLVED: DNS Service Issue and Device Compromise\u2014All Issues Remediated"


def load_env():
    if os.path.isfile(ENV_FILE):
        with open(ENV_FILE) as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    key, _, val = line.partition("=")
                    if key.strip() not in os.environ:
                        os.environ[key.strip()] = val.strip()


load_env()

SMTP_SERVER = os.environ.get("SMTP_SERVER", "")
SMTP_PORT = int(os.environ.get("SMTP_PORT", "587"))
FROM_EMAIL = os.environ.get("FROM_EMAIL", "nms@company.local")
TO_EMAIL = os.environ.get("TO_EMAIL", "stakeholders@company.local")
SMTP_PASSWORD = os.environ.get("SMTP_PASSWORD", "")


def build_body(devices):
    device_list = "\n".join(
        f"  - {d['Device Name']} ({d['Device Address']}, {d['OS']})"
        for d in devices
    )

    return f"""Dear Stakeholders,

This is an automated notification to inform you that the DNS service issue and all related device compromises have been successfully resolved. The following devices were affected and have now been remediated:

{device_list}

No further action is required at this time. If you have any questions or concerns, please contact the IT support team.

Thank you for your attention.

Best regards,
Network Monitoring System"""


def send_email(body, dry_run=True):
    msg = MIMEMultipart()
    msg["From"] = FROM_EMAIL
    msg["To"] = TO_EMAIL
    msg["Subject"] = EMAIL_SUBJECT
    msg.attach(MIMEText(body, "plain"))

    print("=" * 70)
    print("RESOLUTION NOTIFICATION EMAIL")
    print("=" * 70)
    print(f"From    : {FROM_EMAIL}")
    print(f"To      : {TO_EMAIL}")
    print(f"Subject : {EMAIL_SUBJECT}")
    print("-" * 70)
    print(body)
    print("=" * 70)

    if dry_run or not SMTP_SERVER:
        print("\n[DRY RUN] SMTP not configured. Set SMTP_SERVER in .env to send.")
        return

    try:
        with smtplib.SMTP(SMTP_SERVER, SMTP_PORT, timeout=10) as server:
            server.starttls()
            if SMTP_PASSWORD:
                server.login(FROM_EMAIL, SMTP_PASSWORD)
            server.send_message(msg)
        print("\nResolution email sent successfully.")
    except Exception as e:
        print(f"\nFailed to send: {e}")


def main():
    devices = get_affected_devices()
    body = build_body(devices)
    dry_run = not bool(SMTP_SERVER)
    send_email(body, dry_run=dry_run)


if __name__ == "__main__":
    main()