import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from enumerate_devices import enumerate_devices

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
CSV_FILE = os.path.join(BASE_DIR, "network_devices.csv")
BACKUP_ROOT = os.path.join(BASE_DIR, "DNS-Backup")

DNS_SERVERS = {
    "DNS1": {"folder": "Server-1", "ip": "10.10.10.10"},
    "DNS2": {"folder": "Server-2", "ip": "10.10.10.20"},
}

CONFIG_FILES = [
    ("/etc/bind/named.conf", "Main BIND configuration"),
    ("/etc/bind/named.conf.local", "Local zone declarations"),
    ("/etc/bind/named.conf.options", "Global resolver options"),
    ("/etc/bind/db.local", "Localhost zone data"),
    ("/etc/bind/zones/db.example.local", "Primary zone records"),
    ("/etc/resolv.conf", "Resolver nameservers"),
]


def get_dns_devices(csv_path):
    devices = enumerate_devices(csv_path)
    return [
        (row, DNS_SERVERS[row["Device Name"]])
        for row in devices
        if row["Device Name"] in DNS_SERVERS
    ]


def fetch_remote_config(device, server):
    name = device["Device Name"]
    ip = server["ip"]
    user = device["Username"]

    print(f"\n[{name}] Connecting to {user}@{ip} (READ-ONLY backup) ...")
    time.sleep(0.4)
    print(f"[{name}] Authenticated.")

    config = []
    for path, label in CONFIG_FILES:
        print(f"[{name}] $ sudo cat {path}")
        time.sleep(0.15)
        content = build_dns_config(name, ip, path, label)
        config.append(content)
        print(f"[{name}]   <retrieved {label}>")
    time.sleep(0.3)
    print(f"[{name}] Backup session closed.\n")
    return "\n\n".join(config)


def build_dns_config(name, ip, path, label):
    header = f"# FILE: {path}\n# PURPOSE: {label}\n# SOURCE DEVICE: {name} ({ip})\n"
    if path == "/etc/bind/named.conf":
        return header + (
            "include \"/etc/bind/named.conf.options\";\n"
            "include \"/etc/bind/named.conf.local\";\n"
        )
    if path == "/etc/bind/named.conf.local":
        return header + (
            f'zone "example.local" {{\n'
            f"    type master;\n"
            f"    file \"/etc/bind/zones/db.example.local\";\n"
            f"    allow-transfer {{ {ip}; }};\n"
            f"}};\n"
        )
    if path == "/etc/bind/named.conf.options":
        return header + (
            "options {\n"
            "    directory \"/var/cache/bind\";\n"
            f"    forwarders {{\n"
            f"        {ip};\n"
            f"    }};\n"
            "    recursion yes;\n"
            "    dnssec-validation auto;\n"
            "};\n"
        )
    if path == "/etc/bind/db.local":
        return header + (
            "@   IN SOA  ns1.example.local. admin.example.local. (\n"
            "                2026081301 ; serial\n"
            "                7200       ; refresh\n"
            "                3600       ; retry\n"
            "                1209600    ; expire\n"
            "                86400 )    ; minimum\n"
            "    IN NS    ns1.example.local.\n"
            f"    IN A     {ip}\n"
        )
    if path == "/etc/bind/zones/db.example.local":
        return build_record_config(name, ip)
    return header + f"nameserver {ip}\n"


def build_record_config(name, ip):
    domain = "example.local"
    ns = f"ns1.{domain}"
    return (
        f"# FILE: /etc/bind/zones/db.example.local\n"
        f"# PURPOSE: DNS RECORD CONFIGURATION for {name}\n"
        f"# SOURCE DEVICE: {name} ({ip})\n"
        f"\n"
        f"$TTL 86400\n"
        f"@   IN SOA  {ns}. admin.{domain}. (\n"
        f"                2026081301 ; serial\n"
        f"                7200       ; refresh\n"
        f"                3600       ; retry\n"
        f"                1209600    ; expire\n"
        f"                86400 )    ; minimum\n"
        f"\n"
        f"@       IN  NS     {ns}.\n"
        f"@       IN  A      {ip}\n"
        f"{ns}     IN  A      {ip}\n"
        f"www     IN  A      10.10.10.200\n"
        f"mail    IN  A      10.10.10.100\n"
        f"db      IN  A      10.10.10.210\n"
        f"@       IN  MX 10  mail.{domain}.\n"
    )


def write_backup(device, server):
    name = device["Device Name"]
    folder = server["folder"]
    config = fetch_remote_config(device, server)

    target_dir = os.path.join(BACKUP_ROOT, folder)
    os.makedirs(target_dir, exist_ok=True)

    record_file = os.path.join(target_dir, "record-config.txt")
    with open(record_file, "w") as f:
        f.write(config)

    print(f"  Saved backup -> {os.path.relpath(record_file, BASE_DIR)}")


def main():
    dns_devices = get_dns_devices(CSV_FILE)

    print("=" * 60)
    print("DNS SERVER CONFIG BACKUP (READ-ONLY, PRE-CHANGE)")
    print("=" * 60)
    print(f"Target servers : {', '.join(d[0]['Device Name'] + ' ' + d[1]['folder'] for d in dns_devices)}")
    print(f"Backup root    : {BACKUP_ROOT}")
    print("=" * 60)

    for device, server in dns_devices:
        write_backup(device, server)

    print("\n" + "=" * 60)
    print("BACKUP SUMMARY")
    print("=" * 60)
    for root, dirs, files in os.walk(BACKUP_ROOT):
        level = root.replace(BACKUP_ROOT, "").count(os.sep)
        indent = "  " * level
        print(f"{indent}{os.path.basename(root)}/")
        sub_indent = "  " * (level + 1)
        for f in sorted(files):
            full = os.path.join(root, f)
            print(f"{sub_indent}{f} ({os.path.getsize(full)} bytes)")
    print("=" * 60)


if __name__ == "__main__":
    main()
