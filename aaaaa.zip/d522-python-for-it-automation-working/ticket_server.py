import json
from http.server import HTTPServer, BaseHTTPRequestHandler

HOST = "0.0.0.0"
PORT = 8080
next_ticket_id = 1000
tickets = {}


class TicketHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path == "/tickets":
            self._json(200, list(tickets.values()))
            return
        if self.path.startswith("/tickets/"):
            ticket_id = self._ticket_id_from_path()
            if ticket_id is not None and ticket_id in tickets:
                self._json(200, tickets[ticket_id])
            else:
                self._json(404, {"error": "ticket not found"})
            return
        self._json(404, {"error": "not found"})

    def do_POST(self):
        global next_ticket_id

        if self.path != "/tickets":
            self._json(404, {"error": "not found"})
            return

        payload = self._read_payload()

        ticket_id = next_ticket_id
        next_ticket_id += 1

        ticket = {
            "ticket_id": ticket_id,
            "status": "open",
            "device_name": payload["device_name"],
            "ip_address": payload["ip_address"],
            "issue_type": payload["issue_type"],
        }
        tickets[ticket_id] = ticket

        response = dict(ticket)
        response["status"] = "created"
        response["message"] = f"Ticket #{ticket_id} created for {payload['device_name']} ({payload['issue_type']})"

        print(f"[+] Ticket #{ticket_id} | {payload['device_name']} | {payload['ip_address']} | {payload['issue_type']}")
        self._json(201, response)

    def do_PATCH(self):
        prefix = "/tickets/"
        if not self.path.startswith(prefix):
            self._json(404, {"error": "not found"})
            return

        ticket_id = self._ticket_id_from_path()
        if ticket_id is None:
            self._json(400, {"error": "invalid ticket id"})
            return
        if ticket_id not in tickets:
            self._json(404, {"error": "ticket not found"})
            return

        payload = self._read_payload()
        tickets[ticket_id].update(payload)
        ticket = tickets[ticket_id]

        print(f"[*] Ticket #{ticket_id} updated | {ticket['device_name']} | {ticket['ip_address']} | status: {ticket.get('status')}")
        self._json(200, ticket)

    def _ticket_id_from_path(self):
        try:
            return int(self.path.rsplit("/", 1)[1])
        except (ValueError, IndexError):
            return None

    def _read_payload(self):
        length = int(self.headers.get("Content-Length", 0))
        return json.loads(self.rfile.read(length))

    def _json(self, status, data):
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.end_headers()
        self.wfile.write(json.dumps(data).encode())

    def log_message(self, format, *args):
        pass


def main():
    server = HTTPServer((HOST, PORT), TicketHandler)
    print(f"Ticket web service running on http://{HOST}:{PORT}/tickets")
    print("Endpoints: POST /tickets | GET /tickets | GET /tickets/<id> | PATCH /tickets/<id>")
    print("Press Ctrl+C to stop.\n")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nServer stopped.")
        server.server_close()


if __name__ == "__main__":
    main()