import csv
import os

CSV_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "network_devices.csv")


def enumerate_devices(csv_path):
    devices = []
    with open(csv_path, newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            devices.append(row)
    return devices


def print_devices(devices):
    header = f"{'Device ID':<12} {'Name':<14} {'Address':<16} {'Subnet Mask':<18} {'Location':<12} {'Port':<6} {'OS':<14}"
    print("=" * len(header))
    print(header)
    print("-" * len(header))
    for d in devices:
        print(
            f"{d['Device ID']:<12} {d['Device Name']:<14} {d['Device Address']:<16} "
            f"{d['Subnet Mask']:<18} {d['Location']:<12} {d['Access Port']:<6} {d['OS']:<14}"
        )
    print("=" * len(header))
    print(f"Total devices: {len(devices)}")


def main():
    devices = enumerate_devices(CSV_FILE)
    print_devices(devices)


if __name__ == "__main__":
    main()
